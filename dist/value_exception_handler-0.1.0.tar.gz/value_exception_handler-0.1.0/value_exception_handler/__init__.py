from exception_handler import value_error_exception_handler

# Value error exception handler
value_error_exception_handler()
